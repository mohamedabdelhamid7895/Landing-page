/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
 */

/**
 * Define Global Variables*/
 // first Define Sections
 const sections= document.querySelectorAll('section');
 // define Ul list 
 const ul = document.getElementById('navbar__list');
  // create Fragment 
  const fragment= document.createDocumentFragment();
 //const dataText= section.getAttribute('data-nav');
/*** End Global Variables
 * Start Helper Functions**/
 sections.forEach(section=>{
     const li = document.createElement('li');
     // create anchor
    let link =document.createElement('a');
    //adding menu class to anchor
     link.classList.add('menu__link');
     //define data nav
     const dataText= section.getAttribute('data-nav');
     let text =document.createTextNode(dataText);
     //appending  text to anchor 
     link.appendChild(text)
     //appending link to li 
     li.appendChild(link)
     //appending li to fragment 
     fragment.appendChild(li)
     //adding event listener to anchor to navigate sections
     link.addEventListener('click', () => {
    section.scrollIntoView({behavior:'smooth'});
     })
 })
 // appending fragment to Ul 
 ul.appendChild(fragment);
//scroll function 
window.addEventListener('scroll',()=>{
    sections.forEach(section=>{
        let rect =section.getBoundingClientRect();
        section.classList.remove('active-class');
        //adding active class to active section 
        if(rect.top >= 0 && rect.bottom<= window.innerHeight+500){
           section.classList.add('active-class');
           active(section)
        }
    }
    )})
    // active function to add active class to active link 
function active(section) {
    let links = document.querySelectorAll('a');
    let dataId= section.getAttribute("data-nav");
    //looping in links
   links.forEach((link) => {
       link.classList.remove('active-link');
         if(link.textContent==dataId){
             link.classList.add('active-link');
         };
         //adding active class to active section 
         if(link.textContent !== dataId){
             link.classList.remove('active-link')
         }
   })
}