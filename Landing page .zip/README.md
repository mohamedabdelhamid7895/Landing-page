# The General Text
this is the landing page project readme

## the languages used:
- HTML
- CSS
- JAVASCRIPT

## The Functionalities

- The Navigation
- The dynamic active
- The scrolling effect

## What did we learned:
in this project we converted the static web project to a dynamic project

## How to use the project:

first you open your browser
second you click `ctrl+O`
third you navigate to your index.html
forth you click on it
